#coding=utf-8
#
# Copyright (c) 2013 by Pureveg.  All Rights Reserved.
#

CNY_TO_USD = 6.1			# 人民币   换    美金   汇率 
USD_TO_CNY = 6.2			# 美金     换  人民币   汇率 

MIN_VOL_BTC = 10			# BTC最小交易量
MIN_VOL_LTC = 100 			# LTC最小交易量

# 填写 FX 账户
FXBTC_USERNAME = 'Username'
FXBTC_PASSWORD = 'Password'

# 填写BTC-E Key  在设置中找。
BTC_api_key = "BTC_api_key"
BTC_api_secret = "BTC_api_secret"

# 刷新时间(秒)
INTERVAL = 60