#
# Copyright (c) 2013 by Pureveg.  All Rights Reserved.
#
__version__ = "0.1.0"
'''FX API'''

from fxAPI import FX_TradeAPI