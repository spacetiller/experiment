#
# Copyright (c) 2013 by Pureveg.  All Rights Reserved.
#
__version__ = "0.1.0"
'''FX API'''

from btceAPI import btce_Trade